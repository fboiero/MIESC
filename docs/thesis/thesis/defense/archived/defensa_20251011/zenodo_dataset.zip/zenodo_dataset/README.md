# Xaudit v2.0 - Empirical Metrics Dataset

## Métricas Incluidas
- Precision: 89.47%
- Recall: 86.2%
- Cohen's Kappa: 0.847
- False Positive Reduction: 73.6%

## Citar como:
Boiero, F. (2025). Xaudit v2.0 Metrics. Zenodo.
